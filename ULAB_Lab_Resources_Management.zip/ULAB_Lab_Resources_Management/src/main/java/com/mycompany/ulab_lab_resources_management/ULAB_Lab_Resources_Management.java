/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ulab_lab_resources_management;

/**
 *
 * @author Munna
 */
public class ULAB_Lab_Resources_Management {

    public static void main(String[] args) {
        System.out.println("Welcome");
    }
}
