/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ulab_lab_resources_management;

/**
 *
 * @author Munna
 */
public class Session {
   
    public static String currentEmail;
    public static String currentRole;
    public static String currentStudentId;
}
